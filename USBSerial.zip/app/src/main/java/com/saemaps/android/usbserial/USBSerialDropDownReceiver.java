package com.saemaps.android.usbserial;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.atak.plugins.impl.PluginLayoutInflater;
import com.saemaps.android.maps.MapView;
import com.saemaps.android.usbserial.plugin.R;
import com.saemaps.android.dropdown.DropDown.OnStateListener;
import com.saemaps.android.dropdown.DropDownReceiver;

import com.saemaps.android.usbserial.PlatformProxy;
import com.saemaps.coremap.log.Log;

public class USBSerialDropDownReceiver extends DropDownReceiver implements
        OnStateListener {

    public static final String TAG = "USBSerial";

    public static final String SHOW_PLUGIN = "com.saemaps.android.usbserial.SHOW_PLUGIN";
    private final View templateView;
    private final Context pluginContext;

    /**************************** CONSTRUCTOR *****************************/

    public USBSerialDropDownReceiver(final MapView mapView,
                                          final Context context) {
        super(mapView);
        this.pluginContext = context;

        // Remember to use the PluginLayoutInflator if you are actually inflating a custom view
        // In this case, using it is not necessary - but I am putting it here to remind
        // developers to look at this Inflator
        templateView = PluginLayoutInflater.inflate(context,
                R.layout.main_layout, null);

    }

    /**************************** PUBLIC METHODS *****************************/

    public void disposeImpl() {
    }

    /**************************** INHERITED METHODS *****************************/

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "USBSerialDropDownReceiver onReceive called - DEBUG");
        System.out.println("USBSerialDropDownReceiver onReceive called - SYSTEM OUT");

        final String action = intent.getAction();
        if (action == null) {
            Log.w(TAG, "Received intent with null action - DEBUG");
            System.out.println("USBSerialDropDownReceiver received intent with null action - SYSTEM OUT");
            return;
        }

        Log.d(TAG, "Received action: " + action + " - DEBUG");
        System.out.println("USBSerialDropDownReceiver received action: " + action + " - SYSTEM OUT");

        if (action.equals(SHOW_PLUGIN)) {
            Log.d(TAG, "showing plugin drop down - DEBUG");
            System.out.println("USBSerialDropDownReceiver showing plugin drop down - SYSTEM OUT");
            
            // 显示UI界面
            showDropDown(templateView, HALF_WIDTH, FULL_HEIGHT, FULL_WIDTH,
                    HALF_HEIGHT, false, this);
            
            // PlatformProxy逻辑
            new Thread(()->{
                PlatformProxy proxy = PlatformProxy.getInstance();
                if (proxy == null) {
                    ((TextView)templateView.findViewById(R.id.tv_info)).setText("平台代理未初始化，请稍后重试");
                    return;
                }
                
                while (!proxy.isInit()){
                    try {
                        Thread.sleep(5000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                StringBuilder sb = new StringBuilder();
                sb.append("当前平台描述信息：\n").append(proxy.get("Description",String.class)).append('\n')
                        .append("当前平台已安装插件数量：").append(proxy.get("PluginCount",int.class)).append('\n')
                        .append("当前平台已安装插件描述信息：\n").append(proxy.get("PluginDescriptions",String.class)).append('\n');
                ((TextView)templateView.findViewById(R.id.tv_info)).setText(sb.toString());
            }).start();
        }
    }

    @Override
    public void onDropDownSelectionRemoved() {
    }

    @Override
    public void onDropDownVisible(boolean v) {
    }

    @Override
    public void onDropDownSizeChanged(double width, double height) {
    }

    @Override
    public void onDropDownClose() {
        // 插件关闭
    }
}